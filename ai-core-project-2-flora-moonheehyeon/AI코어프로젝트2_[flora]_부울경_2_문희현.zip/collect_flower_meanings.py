"""Collect source-attributed flower meanings; preserve names and original wording."""
import argparse
import hashlib
import html
import json
import re
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')
URL = 'https://www.gutenberg.org/files/31591/31591-h/31591-h.htm'


def clean(value):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', value))).strip()


def parse_greenaway(markup):
    rows, seen = [], set()
    reverse = False
    for table in re.findall(r'<table\b[^>]*summary=[\"\']flowers[\"\'][^>]*>(.*?)</table>', markup, re.S | re.I):
        if 'id="page_48"' in table:
            reverse = True  # The second half is a meaning-to-flower index.
        for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>', table, re.S | re.I):
            cells = re.findall(r'<td\b[^>]*>(.*?)</td>', row, re.S | re.I)
            if len(cells) != 2:
                continue
            name, meaning = map(clean, cells)
            if reverse:
                name, meaning = meaning.rstrip('.'), name
            key = (name.casefold().rstrip('.'), meaning.casefold().rstrip('.'))
            if not name or not meaning or key in seen:
                continue
            seen.add(key)
            rows.append({'id': 'greenaway-' + hashlib.sha256(repr(key).encode()).hexdigest()[:16],
                         'name': name, 'meaning': meaning, 'url': URL,
                         'source': 'Kate Greenaway · Language of Flowers',
                         'language': 'en', 'tradition': '영문 역사 꽃말 사전'})
    if len(rows) < 500:
        raise ValueError(f'Unexpected source layout: only {len(rows)} records; existing data preserved.')
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--refresh', action='store_true', help='Download source again')
    args = parser.parse_args()
    cache = ROOT / 'research/greenaway_flowers.html'
    if args.refresh or not cache.exists():
        session=requests.Session()
        contact=os.getenv('WIKI_CONTACT','').strip()
        session.headers['User-Agent']=f'FloraAI/0.1 ({contact}) flower-meaning research' if contact else 'FloraAI/0.1 flower-meaning research'
        session.mount('https://',HTTPAdapter(max_retries=Retry(total=3,backoff_factor=1,status_forcelist=[429,500,502,503,504])))
        time.sleep(0.7)
        response = session.get(URL, timeout=45)
        response.raise_for_status()
        response.encoding = 'utf-8'
        markup = response.text
    else:
        markup = cache.read_text(encoding='utf-8')
    historic = parse_greenaway(markup)
    domestic = json.loads((ROOT / 'data/nihhs_dictionary.json').read_text(encoding='utf-8'))
    records = [{**r, 'id':'nihhs-'+r['id'], 'source':'국립원예특작과학원 꽃말사전',
                'language':'ko', 'tradition':'국내 꽃말 사전'} for r in domestic] + historic
    output = {'collected_at':datetime.now(timezone.utc).isoformat(),
              'records':records, 'counts':{'nihhs':len(domestic), 'greenaway':len(historic),
              'total':len(records), 'distinct_source_names':len({r['name'] for r in records})},
              'note':'색상·상태·통칭·나무를 포함한 출처별 항목 수이며 식물학적 종 수가 아닙니다. 영문 자료는 역사적 꽃말의 원문입니다.'}
    target = ROOT / 'data/flower_meanings.json'
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(target)
    print(json.dumps(output['counts']))


if __name__ == '__main__':
    main()
