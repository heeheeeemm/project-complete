"""위키백과 대표 사진과 파일별 저작자·라이선스 정보 조회."""
import html
import json
import os
import re
import time
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from flora.config import ROOT

def _text(value):
    return re.sub(r'\s+', ' ',html.unescape(re.sub(r'<[^>]+>',' ',value))).strip()


def is_photograph(info, title=''):
    """Conservatively select camera photos, excluding botanical artwork/scans."""
    meta = info.get('extmetadata', {})
    description = ' '.join(str(meta.get(key, {}).get('value', '')) for key in ['Categories','ImageDescription','ObjectName'])
    text = (title+' '+info.get('descriptionurl','')+' '+description).casefold()
    if re.search(r'\b(?:seeds?|fruits?|leaves|leaf|stems?|roots?|pollen|range|map|logo|icon)\b', title.casefold()):
        return False
    if re.search(r'illustrat|botanical (?:art|drawing)|drawing|engraving|painting|lithograph|watercolou?r|sturm|köhler|koehler|thom[eé]|도판|삽화|세밀화|일러스트', text):
        return False
    if info.get('mime') not in ('image/jpeg', 'image/png', 'image/webp'):
        return False
    camera = any(str(m.get('name','')).casefold() in ('make','model','datetimeoriginal','exposuretime','fnumber') for m in info.get('metadata', []))
    return camera or bool(re.search(r'photograph|photography|사진|촬영|\b(?:dsc|img|pxl)[_ -]?\d', text))

def fetch_photo(page_id, name=None):
    cache = ROOT / 'data/flower_photos.json'
    saved = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if str(page_id) in saved and saved[str(page_id)].get('image_kind') == 'photograph':
        return saved[str(page_id)]
    session = requests.Session()
    contact = os.getenv('WIKI_CONTACT','').strip()
    session.headers['User-Agent'] = f'FloraAI/0.1 ({contact}) python-requests' if contact else 'FloraAI/0.1 python-requests'
    session.mount('https://', HTTPAdapter(max_retries=Retry(
        total=2, connect=1, read=1, status=2, backoff_factor=0.7,
        status_forcelist=[429,500,502,503,504])))
    photo_articles = {
        '2657069':'Dahlia', 'nihhs-269':'Heliotropium arborescens',
        'nihhs-241':'Canna indica', 'nihhs-321':'Gypsophila paniculata',
        '282899':'Lily of the valley',
    }
    english_article = photo_articles.get(str(page_id))
    def query(params, commons=False):
        endpoint = 'https://commons.wikimedia.org/w/api.php' if commons else ('https://en.wikipedia.org/w/api.php' if english_article else 'https://ko.wikipedia.org/w/api.php')
        time.sleep(0.7)
        r = session.get(endpoint,params={
            'action':'query','format':'json','formatversion':2,'redirects':1,**params},timeout=(3,5))
        r.raise_for_status()
        data = r.json()
        if 'error' in data:
            raise ValueError('사진 정보를 가져오지 못했습니다.')
        return data.get('query',{}).get('pages',[])
    # '목화'는 동음이의 문서이므로 사진만 목화속 문서에서 가져온다.
    photo_title = {'목화':'목화속'}.get(name, name)
    lookup = {'titles':english_article} if english_article else ({'titles':photo_title} if name else {'pageids':str(page_id)})
    pages = query({**lookup,'prop':'pageimages|pageprops','piprop':'thumbnail|name',
                   'pithumbsize':640,'pilicense':'free'})
    page = pages[0] if pages else {}
    if page.get('missing') or page.get('pageprops',{}).get('disambiguation') is not None:
        return None
    resolved_id = page.get('pageid', page_id)
    filename = page.get('pageimage')
    pages = query({'pageids':str(resolved_id),'prop':'images','imlimit':20})
    titles = ([('File:'+filename)] if filename else []) + [image['title'] for p in pages for image in p.get('images',[])
              if re.search(r'\.(?:jpe?g|png|webp)$',image['title'],re.I)]
    titles = list(dict.fromkeys(re.sub(r'^파일:', 'File:', t) for t in titles))
    entity_id = page.get('pageprops',{}).get('wikibase_item')
    if entity_id:
        response = session.get(f'https://www.wikidata.org/wiki/Special:EntityData/{entity_id}.json', timeout=(3,5))
        response.raise_for_status()
        claims = response.json().get('entities',{}).get(entity_id,{}).get('claims',{})
        entity_photos = ['File:'+claim['mainsnak']['datavalue']['value'] for claim in claims.get('P18',[])
                         if claim.get('mainsnak',{}).get('datavalue')]
        titles = list(dict.fromkeys(entity_photos+titles))
    if not titles:
        return None
    files = query({'titles':'|'.join(titles),'prop':'imageinfo',
                   'iiprop':'url|extmetadata|metadata|mime','iiurlwidth':480},commons=True)
    # Prefer the representative photo if valid; otherwise use a photographed alternative.
    files.sort(key=lambda p: titles.index(p['title']) if p.get('title') in titles else len(titles))
    info = next((p['imageinfo'][0] for p in files if p.get('imageinfo')
                 and is_photograph(p['imageinfo'][0], p.get('title',''))
                 and p['imageinfo'][0].get('extmetadata',{}).get('LicenseShortName',{}).get('value')),None)
    if not info:
        return None
    meta = info.get('extmetadata',{})
    return {'url':info.get('thumburl') or info['url'],'source_url':info.get('descriptionurl',''),
            'image_kind':'photograph',
            'artist':_text(meta.get('Artist',{}).get('value','저작자 정보는 원문 참조')),
            'license':_text(meta.get('LicenseShortName',{}).get('value','이용 조건은 원문 참조')),
            'license_url':meta.get('LicenseUrl',{}).get('value','')}
