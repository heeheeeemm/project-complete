import json
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')
SETTINGS = json.loads((ROOT / 'flora_settings.json').read_text(encoding='utf-8'))
BASE_URL = 'https://gms.ssafy.io/gmsapi/api.openai.com/v1/'

def model():
    from langchain_openai import ChatOpenAI
    if not os.getenv('GMS_KEY'):
        raise ValueError('GMS_KEY 설정이 필요합니다.')
    return ChatOpenAI(model=SETTINGS['model'], api_key=os.environ['GMS_KEY'],
                      base_url=BASE_URL, timeout=60, max_retries=1)

def embeddings():
    from langchain_openai import OpenAIEmbeddings
    return OpenAIEmbeddings(model=SETTINGS['embedding_model'], api_key=os.getenv('GMS_KEY'),
                            base_url=BASE_URL, check_embedding_ctx_length=False,
                            request_timeout=60, max_retries=2, chunk_size=64)
