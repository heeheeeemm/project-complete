"""Flora AI 화면의 공통 스타일과 소개 영역."""
import base64
import html
import json
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]


def apply_styles():
    css = (ROOT / 'assets' / 'flora.css').read_text(encoding='utf-8')
    st.markdown('<style>' + css + '</style>', unsafe_allow_html=True)


@st.cache_data(show_spinner=False)
def hero_photo():
    cache = ROOT / 'data' / 'flower_photos.json'
    if not cache.exists():
        return None
    photo = json.loads(cache.read_text(encoding='utf-8')).get('282899', {})
    path = ROOT / photo.get('local_path', '__missing__')
    if not path.is_file():
        return None
    return {'image':base64.b64encode(path.read_bytes()).decode('ascii'), **photo}


def sidebar_brand():
    st.markdown('''<div class="flora-brand"><span class="brand-flower" aria-hidden="true">✳</span>
<div><strong>flora<span>.</span></strong><small>마음을 전하는 작은 정원</small></div></div>
<div class="sidebar-eyebrow">YOUR FLOWER COMPANION</div>''', unsafe_allow_html=True)


def hero():
    photo = hero_photo()
    visual = ''
    if photo:
        source = html.escape(photo.get('source_url', ''), quote=True)
        license_url = html.escape(photo.get('license_url', source), quote=True)
        artist = html.escape(photo.get('artist', ''))
        license_name = html.escape(photo.get('license', ''))
        visual = f'''<div class="hero-visual">
<div class="photo-orbit" aria-hidden="true"></div>
<img class="hero-flower" src="data:image/jpeg;base64,{photo['image']}" alt="초록 잎 사이로 피어난 하얀 은방울꽃" />
<div class="flower-label"><span class="label-star" aria-hidden="true">✳</span><div><small>A LITTLE NOTE</small><strong>마음이 피어나는 순간</strong></div></div>
<div class="hero-photo-credit"><a href="{source}" target="_blank" rel="noopener noreferrer">사진 · {artist}</a> · <a href="{license_url}" target="_blank" rel="noopener noreferrer">{license_name}</a></div>
</div>'''
    st.markdown(f'''<div class="studio-topline"><span>FLORA AI <i>/</i> FLOWER & FEELING</span><span>꽃이 전하는 마음을 읽다</span></div>
<section class="hero {'hero-without-photo' if not photo else ''}">
<div class="hero-copy"><div class="hero-eyebrow"><span></span> A LITTLE FLOWER, A LOT OF FEELING</div>
<h1>그 마음,<br><em>어떤 꽃으로</em> 전할까요?</h1>
<p>고마움도, 설레는 고백도, 조용한 응원도.<br>전하고 싶은 마음에 어울리는 꽃말과 한 문장을 찾아드려요.</p>
<div class="hero-tags"><span>꽃말로 전하는 진심</span><span>출처와 함께 찾는 꽃</span></div></div>
{visual}</section>''', unsafe_allow_html=True)


def section_intro(number, eyebrow):
    st.markdown(f'<div class="section-eyebrow"><span>{html.escape(number)}</span> {html.escape(eyebrow)}</div>', unsafe_allow_html=True)


def gift_note(text):
    st.markdown('<div class="gift-note"><span>함께 전할 카드 문구</span><p>' +
                html.escape(text).replace('\n', '<br>') + '</p><small>WITH LOVE, FLORA</small></div>', unsafe_allow_html=True)


def footer():
    st.markdown('''<footer class="flora-footer"><span>flora<span class="footer-dot">.</span></span>
<p>말로 다 못한 마음에, 꽃 한 송이.</p><small>FLOWERS SPEAK WHEN WORDS ARE NOT ENOUGH</small></footer>''', unsafe_allow_html=True)
