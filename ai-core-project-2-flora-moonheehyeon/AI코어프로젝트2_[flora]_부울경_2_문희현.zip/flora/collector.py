"""질문별 위키백과 후보 검색·LLM 선별·수집 캐시."""
import hashlib
import json
import os
import threading
import time
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from flora.config import ROOT, SETTINGS
from flora.pipeline import json_call
from prepare_flora import clean_wiki

LOCK = threading.Lock()

def collect(plant, question, store, progress=lambda message: None):
    contact = os.getenv('WIKI_CONTACT','').strip()
    ua = f'FloraAI/0.1 ({contact}) python-requests' if contact else 'FloraAI/0.1 python-requests'
    ua.encode('ascii')
    cache_dir = ROOT/'data/search_cache'
    cache_dir.mkdir(parents=True,exist_ok=True)
    query_dir = ROOT/'data/query_cache'
    query_dir.mkdir(parents=True,exist_ok=True)
    question_key = hashlib.sha256((plant['id']+':'+question.strip()).encode()).hexdigest()
    query_path = query_dir/f'{question_key}.json'
    progress('질문에서 검색어를 추출하고 있습니다…')
    if query_path.exists():
        extraction = json.loads(query_path.read_text(encoding='utf-8'))
    else:
        extraction = json_call('너는 식물 전문가다. 식물과 질문에서 한국어 위키백과 검색어를 최대 2개 뽑는다. '
                               '형식: {"queries":["검색어"]}. 선택 식물 이름을 포함한다.',
                               {'plant':plant['name'],'question':question})
        query_path.write_text(json.dumps(extraction,ensure_ascii=False),encoding='utf-8')
    queries = list(dict.fromkeys([plant['name']]+[q for q in extraction.get('queries',[]) if isinstance(q,str) and q.strip()]))[:2]
    session = requests.Session()
    session.headers['User-Agent'] = ua
    session.mount('https://', HTTPAdapter(max_retries=Retry(total=3,backoff_factor=2,status_forcelist=[429,500,502,503,504])))
    def request(params):
        time.sleep(0.7)
        response = session.get('https://ko.wikipedia.org/w/api.php',params={**params,'format':'json','formatversion':2},timeout=25)
        response.raise_for_status()
        result = response.json()
        if 'error' in result:
            raise ValueError('위키백과 응답 오류')
        return result
    count = 0
    for query in queries:
        key = hashlib.sha256((plant['id']+':'+query).encode()).hexdigest()
        path = cache_dir/f'{key}.json'
        with LOCK:
            if path.exists():
                progress('저장된 문서 색인을 재사용합니다.')
                continue
            progress(f'관련 문서 후보를 검색하고 있습니다: {query}')
            candidates = request({'action':'query','list':'search','srsearch':query,'srlimit':SETTINGS['external_search_limit']})['query']['search']
            selection = json_call('너는 식물 문서 선별자다. 질문과 관련된 후보만 최대 2개 고른다. '
                '형식: {"page_ids":[123]}. 식물 자체 문서는 이미 별도로 확보되었다. 무관한 후보는 제외한다.',
                {'plant':plant['name'],'question':question,'candidates':candidates}) if candidates else {'page_ids':[]}
            allowed = {str(c['pageid']) for c in candidates}
            ids = [str(i) for i in selection.get('page_ids',[]) if str(i) in allowed][:2]
            for pid in ids:
                if pid == plant['id']:
                    continue
                progress('선별한 문서를 수집하고 색인하고 있습니다…')
                pages = request({'action':'query','pageids':pid,'prop':'revisions|info','rvprop':'content',
                                 'rvslots':'main','inprop':'url'})['query']['pages']
                for page in pages:
                    if page.get('missing'):
                        continue
                    raw = page.get('revisions',[{}])[0].get('slots',{}).get('main',{}).get('content','')
                    text = clean_wiki(raw)
                    if not text:
                        continue
                    records = store.document_records(plant['id'],page['pageid'],page['title'],page['fullurl'],text,'위키백과')
                    store.upsert(store.docs, records)
                    count += 1
            # 선별에서 제외한 후보도 남겨 검색어 추출과 문서 선별을 대조할 수 있게 한다.
            audit_candidates = [{'page_id':str(c['pageid']), 'title':c['title'],
                                 'selected':str(c['pageid']) in ids,
                                 'already_indexed_primary':str(c['pageid']) == plant['id']}
                                for c in candidates]
            path.write_text(json.dumps({'query':query,'selected_ids':ids,
                                        'candidates':audit_candidates,
                                        'rejected_ids':[c['page_id'] for c in audit_candidates if not c['selected']],
                                        'collected_at':time.time()},ensure_ascii=False),encoding='utf-8')
    return count
