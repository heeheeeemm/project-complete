import hashlib
import json
import chromadb
from chromadb.config import Settings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from flora.config import ROOT, SETTINGS, embeddings
from flora.data import meta_text

class Store:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=str(ROOT/'data/chroma'), settings=Settings(anonymized_telemetry=False))
        self.meta = self.client.get_or_create_collection('plant_meta', metadata={'hnsw:space':'cosine'})
        self.docs = self.client.get_or_create_collection('plant_docs', metadata={'hnsw:space':'cosine'})
        self.embedder = embeddings()

    def split(self, text):
        return RecursiveCharacterTextSplitter(chunk_size=SETTINGS['chunk_size'], chunk_overlap=SETTINGS['chunk_overlap'],
                                              separators=['\n\n','\n','. ',' ','']).split_text(text)

    def upsert(self, collection, records, progress=None):
        if not records:
            return
        old = collection.get(ids=[r['id'] for r in records], include=['metadatas'])
        hashes = {i:m.get('content_hash') for i,m in zip(old['ids'], old['metadatas'])}
        todo = []
        for r in records:
            digest = hashlib.sha256(r['text'].encode()).hexdigest()
            if hashes.get(r['id']) != digest:
                r['metadata']['content_hash'] = digest
                todo.append(r)
        for start in range(0,len(todo),64):
            batch = todo[start:start+64]
            vectors = self.embedder.embed_documents([r['text'] for r in batch])
            collection.upsert(ids=[r['id'] for r in batch], documents=[r['text'] for r in batch],
                              metadatas=[r['metadata'] for r in batch], embeddings=vectors)
            if progress:
                progress(min(start+64,len(todo)),len(todo))

    def document_records(self, plant_id, document_id, title, url, text, source_type):
        return [{'id':f'{plant_id}:{document_id}:{i}', 'text':t,
                 'metadata':{'plant_id':str(plant_id),'title':title,'url':url,'source_type':source_type,
                             'document_id':str(document_id)}} for i,t in enumerate(self.split(text))]

    def index(self, plants, progress=None):
        metas, docs = [], []
        for p in plants:
            metas.append({'id':p['id'], 'text':meta_text(p), 'metadata':{
                'plant_id':p['id'],'title':p['name']+' · 식물 정보','url':p['url'],'source_type':'항목 메타데이터'}})
            # 사전 전용 항목의 ID는 nihhs-<번호>라서 꽃말 문서 ID와 겹친다.
            # 본문에는 별도 ID를 부여해 재색인 시 DuplicateIDError를 방지한다.
            primary_id = 'primary-'+p['id'] if p['id'].startswith('nihhs-') else p['id']
            docs.extend(self.document_records(p['id'],primary_id,p['name'],p['url'],p['text'],p.get('source_type','위키백과')))
            for r in p['meanings']:
                docs.extend(self.document_records(p['id'],'nihhs-'+r['id'],r['name']+' · 꽃말',r['url'],
                    f"국립원예특작과학원 꽃말사전\n식물: {r['name']}\n꽃말: {r['meaning']}\n이 의미는 해당 출처의 표현이다.",'국립원예특작과학원'))
        self.upsert(self.meta, metas, progress)
        self.upsert(self.docs, docs, progress)
        # 청크 설정 변경 시 이전 순번이 남지 않게 기본 문서의 오래된 청크만 정리한다.
        expected = {r['id'] for r in docs}
        actual = self.docs.get(include=['metadatas'])
        plant_ids = {p['id'] for p in plants}
        stale = [i for i,m in zip(actual['ids'],actual['metadatas'])
                 if m['plant_id'] in plant_ids and (m['document_id']==m['plant_id'] or m['document_id'].startswith(('nihhs-','primary-'))) and i not in expected]
        if stale:
            self.docs.delete(ids=stale)
        (ROOT/'data/index_manifest.json').write_text(json.dumps({'plants':len(plants), 'chunks':self.docs.count(),
             'chunk_size':SETTINGS['chunk_size'], 'chunk_overlap':SETTINGS['chunk_overlap'],
             'embedding_model':SETTINGS['embedding_model']},ensure_ascii=False,indent=2),encoding='utf-8')

    def retrieve(self, plant, question):
        meta = self.meta.get(ids=[plant['id']],include=['documents','metadatas'])
        if not meta['ids']:
            if plant['id'].startswith('nihhs-'):
                return [{'id':'meaning:'+r['id'], 'text':f"{r['name']}의 꽃말: {r['meaning']}",
                         'title':r['name']+' · 꽃말', 'url':r['url'],
                         'source_type':'국립원예특작과학원'} for r in plant['meanings']]
            raise ValueError('식물 색인이 없습니다. 먼저 색인을 준비해 주세요.')
        result = [{'id':meta['ids'][0], 'text':meta['documents'][0], **meta['metadatas'][0]}]
        docs = self.docs.query(query_embeddings=[self.embedder.embed_query(question)],
                               where={'plant_id':plant['id']},n_results=SETTINGS['top_k'],include=['documents','metadatas'])
        seen = set()
        for i,t,m in zip(docs['ids'][0],docs['documents'][0],docs['metadatas'][0]):
            if t not in seen:
                result.append({'id':i,'text':t,**m})
                seen.add(t)
        # 꽃말 질의에는 출처가 있는 꽃말 문서를 우선 보완한다.
        if any(w in question for w in ['꽃말','마음','선물','사랑','감사']):
            for r in plant['meanings']:
                if any(s.get('document_id')=='nihhs-'+r['id'] for s in result):
                    continue
                t = f"{r['name']}의 꽃말: {r['meaning']}"
                result.append({'id':'meaning:'+r['id'],'text':t,'title':r['name']+' · 꽃말',
                               'url':r['url'],'source_type':'국립원예특작과학원'})
        return result
