import json
from flora.config import ROOT

def load_data():
    path = ROOT / 'data/plants.json'
    if not path.exists():
        return {'plants':[], 'meaning_count':0, 'dictionary_count':0}
    data = json.loads(path.read_text(encoding='utf-8'))
    dictionary_path = ROOT / 'data/nihhs_dictionary.json'
    dictionary = json.loads(dictionary_path.read_text(encoding='utf-8')) if dictionary_path.exists() else []
    # 꽃말사전의 이름을 그대로 유지한다. 종/속 또는 색상별 의미를 추정해 합치지 않는다.
    plants = data['plants']
    by_name = {}
    for plant in plants:
        for name in plant['aliases'] + [plant['name']]:
            by_name.setdefault(name, plant)
    for row in dictionary:
        plant = by_name.get(row['name'])
        if plant:
            if not any(r['id'] == row['id'] for r in plant['meanings']):
                plant['meanings'].append(row)
            continue
        plant = {'id':'nihhs-'+row['id'], 'name':row['name'], 'aliases':[row['name']],
                 'scientific_name':'', 'family':'', 'rank':'꽃말사전 항목',
                 'text':f"국립원예특작과학원 꽃말사전의 {row['name']} 항목입니다. 꽃말: {row['meaning']}",
                 'url':row['url'], 'revision':0, 'flowering_evidence':[], 'colors':[],
                 'meanings':[row], 'source_type':'국립원예특작과학원'}
        plants.append(plant)
        by_name[row['name']] = plant
    data['meaning_count'] = sum(bool(p['meanings']) for p in plants)
    data['dictionary_count'] = len(dictionary)
    return data


def load_meanings():
    path = ROOT / 'data/flower_meanings.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'records':[], 'counts':{}}

def meta_text(p):
    meanings = ' / '.join(r['meaning'] for r in p['meanings']) or '공식 꽃말 미확인'
    return (f"식물: {p['name']}\n다른 이름: {', '.join(p['aliases'])}\n"
            f"학명: {p['scientific_name'] or '미확인'}\n분류: {p['family']} ({p['rank']})\n"
            f"꽃말: {meanings}\n특징: {p['text'][:1000]}\n"
            f"개화 관련 원문: {' '.join(p['flowering_evidence'])}")
