import json
import unittest

from collect_flower_meanings import ROOT, parse_greenaway
from flora.data import load_data, load_meanings
from flora.pipeline import explore


class FlowerCollectionTests(unittest.TestCase):
    def test_gratitude_offers_six_distinct_flowers_with_honest_evidence(self):
        matches = explore(load_data()['plants'], '감사의 마음', True, related=True)
        self.assertEqual(len(matches), 6)
        self.assertEqual(len({m['plant']['id'] for m in matches}), 6)
        self.assertEqual(matches[0]['match_type'], '직접 일치')
        self.assertTrue(any(m['match_type'] == '관련 마음' for m in matches))
        for match in matches:
            for evidence in match['evidence']:
                self.assertTrue(any(evidence['quote'] == r['meaning'] for r in match['plant']['meanings']))
            if match['match_type'] == '관련 마음':
                self.assertNotIn('뜻은 아니에요', match['reason'])
                self.assertTrue(any(r['meaning'] in match['reason'] for r in match['plant']['meanings']))

    def test_all_domestic_dictionary_records_are_recommendable(self):
        dictionary = json.loads((ROOT/'data/nihhs_dictionary.json').read_text(encoding='utf-8'))
        plants = load_data()['plants']
        linked = {r['id'] for p in plants for r in p['meanings']}
        self.assertTrue({r['id'] for r in dictionary} <= linked)
        cotton = next(p for p in plants if p['name'] == '목화')
        self.assertIn('어머니의 사랑', cotton['meanings'][0]['meaning'])

    def test_recipient_word_does_not_add_an_unrequested_feeling(self):
        plants=load_data()['plants']
        for query in ['고마운 친구에게 선물할 꽃','감사를 전할 연인에게 줄 꽃']:
            matches=explore(plants,query,True,related=True)
            self.assertTrue(matches)
            self.assertEqual(matches[0]['match_type'],'직접 일치')
            self.assertTrue(any('감사' in r['meaning'] for r in matches[0]['plant']['meanings']))

    def test_historical_reverse_index_is_not_a_flower_name(self):
        rows = parse_greenaway((ROOT/'research/greenaway_flowers.html').read_text(encoding='utf-8'))
        self.assertFalse(any(r['name'] == 'Absence' for r in rows))
        self.assertTrue(any(r['name'] == 'Wormwood' and r['meaning'].rstrip('.') == 'Absence' for r in rows))
        self.assertEqual(len(rows), len({r['id'] for r in rows}))

    def test_catalog_has_sources_and_no_duplicate_pairs(self):
        rows = load_meanings()['records']
        self.assertGreater(len(rows), 1000)
        self.assertTrue(all(r['name'] and r['meaning'] and r['url'].startswith('https://') and r['source'] for r in rows))
        keys = [(r['source'], r['name'].casefold().rstrip('.'), r['meaning'].casefold().rstrip('.')) for r in rows]
        self.assertEqual(len(keys), len(set(keys)))
