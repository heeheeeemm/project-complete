import unittest
from pathlib import Path
from unittest.mock import patch

from streamlit.testing.v1 import AppTest


class FlowerNavigationTests(unittest.TestCase):
    def test_typed_query_overrides_default_gratitude_and_old_results(self):
        with patch('flora.photos.fetch_photo', return_value=None), patch('flora.cards.json_call', return_value={'cards':[]}):
            app = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=15).run()
            submit = lambda: next(b for b in app.button if b.label == '내 마음에 어울리는 꽃 찾기').click().run()
            submit()
            self.assertFalse(app.exception)
            app.text_input(key='recommend_input').set_value('사랑을 전하고 싶어요').run()
            submit()
            self.assertFalse(app.exception)
            results = app.session_state['recommend_results']
            self.assertTrue(results)
            self.assertTrue(all(any('사랑' in r['meaning'] for r in m['plant']['meanings']) for m in results))
            self.assertNotIn('감사', app.session_state['recommend_query'])
            # 이미 세션에 저장된 과거 추천도 새 표시 정책을 적용한다.
            results[0]['reason'] += " 꽃말 자체가 '사랑'이라는 뜻은 아니에요."
            app.run()
            self.assertFalse(any('꽃말 자체가' in m.value for m in app.markdown))
            app.text_input(key='recommend_input').set_value('목화').run()
            submit()
            self.assertFalse(app.exception)
            self.assertEqual([m['plant']['name'] for m in app.session_state['recommend_results']], ['목화'])
            app.text_input(key='direct_flower_search').set_value('장미').run()
            self.assertFalse(app.exception)
            self.assertFalse(any(m.value == '### 🌼 목화' for m in app.markdown))
            self.assertTrue(any(s.value == '장미' for s in app.subheader))

    def test_open_return_and_search_another_flower_with_photo_failure(self):
        with patch('flora.photos.fetch_photo', return_value=None) as photo, patch('flora.cards.json_call', return_value={'cards':[]}):
            app = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=15).run()
            self.assertFalse(app.exception)
            # A hidden detail tab must not fetch the default plant's photo.
            photo.assert_not_called()
            app.text_input(key='direct_flower_search').set_value('목화').run()
            self.assertFalse(app.exception)
            app.button(key='direct_nihhs-198').click().run()
            self.assertFalse(app.exception)
            self.assertEqual(app.session_state['plant_id'], 'nihhs-198')
            app.button(key='back_to_recommend').click().run()
            self.assertFalse(app.exception)
            self.assertEqual(app.text_input(key='direct_flower_search').value, '목화')
            app.text_input(key='direct_flower_search').set_value('장미').run()
            self.assertFalse(app.exception)
            self.assertTrue(any(s.value == '장미' for s in app.subheader))
            before = photo.call_count
            app.run()
            self.assertFalse(app.exception)
            self.assertEqual(photo.call_count, before)
