import copy
import hashlib
import tempfile
import unittest
import chromadb
from pathlib import Path
from unittest.mock import patch
from flora.pipeline import cited_sources, explore
from flora.store import Store
from flora.collector import collect

class FakeEmbeddings:
    def embed_query(self,text):
        b = hashlib.sha256(text.encode()).digest()
        return [float(v+1) for v in b[:8]]
    def embed_documents(self,texts):
        return [self.embed_query(t) for t in texts]

class FloraTests(unittest.TestCase):
    def plant(self,pid,name):
        return {'id':pid,'name':name,'aliases':[name],'scientific_name':'','family':'','rank':'종',
                'text':name+' 꽃은 봄에 핀다. '*120,'url':'https://example.org/'+pid,
                'flowering_evidence':['꽃은 봄에 핀다.'],'meanings':[]}

    def test_index_is_idempotent_and_retrieval_is_scoped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'data').mkdir()
            memory = chromadb.EphemeralClient()
            with patch('flora.store.ROOT',root),patch('flora.store.embeddings',return_value=FakeEmbeddings()),patch('flora.store.chromadb.PersistentClient',return_value=memory):
                store = Store()
                plants = [self.plant('a','장미'),self.plant('b','수국')]
                store.index(copy.deepcopy(plants))
                counts = (store.meta.count(),store.docs.count())
                store.index(copy.deepcopy(plants))
                self.assertEqual(counts,(store.meta.count(),store.docs.count()))
                sources = store.retrieve(plants[0],'개화기')
                self.assertEqual(sources[0]['source_type'],'항목 메타데이터')
                self.assertTrue(all(s['plant_id']=='a' for s in sources))

    def test_only_cited_sources_are_displayed(self):
        sources = [{'title':'a'},{'title':'b'},{'title':'c'}]
        self.assertEqual([i for i,_ in cited_sources('설명 [근거 1, 3] [근거 99]',sources)],[1,3])
        self.assertEqual(cited_sources('확인할 수 없습니다.',sources),[])

    def test_dictionary_only_plant_has_unique_document_ids_after_rechunking(self):
        plant = self.plant('nihhs-46','목화')
        plant['meanings'] = [{'id':'46','name':'목화','meaning':'어머니의 사랑','url':plant['url']}]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'data').mkdir()
            # 별도 컬렉션으로 다른 테스트와 분리한다.
            memory = chromadb.EphemeralClient()
            for name in ['plant_meta','plant_docs']:
                memory.get_or_create_collection(name).delete(where={'plant_id':{'$ne':'__none__'}})
            with patch('flora.store.ROOT',root), patch('flora.store.embeddings',return_value=FakeEmbeddings()), patch('flora.store.chromadb.PersistentClient',return_value=memory):
                store = Store()
                for size in [200,500,200]:
                    with patch.dict('flora.store.SETTINGS',chunk_size=size,chunk_overlap=30):
                        store.index([plant])
                        expected = 0
                        records = store.docs.get(include=['metadatas'])
                        for document_id in {m['document_id'] for m in records['metadatas']}:
                            expected += len(store.split(plant['text'])) if document_id.startswith('primary-') else 1
                        self.assertEqual(store.docs.count(),expected)
                        store.index([plant])
                        self.assertEqual(store.docs.count(),expected)

    def test_gratitude_recommendation_requires_gratitude_meaning(self):
        good,bad = self.plant('a','다알리아'),self.plant('b','장미')
        good['meanings']=[{'meaning':'감사, 우아'}]
        bad['meanings']=[{'meaning':'사랑, 순결'}]
        result = explore([good,bad],'고마운 사람에게 꽃을 선물하고 싶어',True)
        self.assertEqual([r['plant']['id'] for r in result],['a'])

    def test_search_rejects_missing_or_fabricated_condition_evidence(self):
        plant = self.plant('a','장미')
        response = {'conditions':['봄','분홍색'], 'matches':[{'id':'a','reason':'추천',
                     'evidence':[{'condition':'봄','quote':'꽃은 봄에 핀다.'},
                                 {'condition':'분홍색','quote':'분홍색 꽃이다.'}]}]}
        with patch('flora.pipeline.json_call',return_value=response):
            self.assertEqual(explore([plant],'봄 분홍색'),[])
        response['conditions']=['봄']
        with patch('flora.pipeline.json_call',return_value=response):
            self.assertEqual(len(explore([plant],'봄')),1)

    def test_search_checks_later_batches_for_more_matches(self):
        plants = [self.plant(str(i),'꽃'+str(i)) for i in range(21)]
        def respond(system,payload):
            return {'conditions':['봄'],'matches':[
                {'id':p['id'],'reason':'봄꽃','evidence':[
                    {'condition':'봄','quote':'꽃은 봄에 핀다.'}]} for p in payload['plants'][-1:]]}
        with patch('flora.pipeline.json_call',side_effect=respond) as call:
            matches = explore(plants,'봄에 피는 꽃')
        self.assertEqual([m['plant']['id'] for m in matches],['19','20'])
        self.assertEqual(call.call_count,2)

    def test_repeated_question_reuses_extraction_and_collection_cache(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch('flora.collector.ROOT',Path(tmp)), \
                 patch('flora.collector.json_call',return_value={'queries':['장미']}) as extract, \
                 patch('flora.collector.time.sleep'), \
                 patch('flora.collector.requests.Session.get') as request:
                request.return_value.json.return_value = {'query':{'search':[]}}
                plant = self.plant('a','장미')
                self.assertEqual(collect(plant,'장미의 특징',None),0)
                self.assertEqual(collect(plant,'장미의 특징',None),0)
                self.assertEqual(extract.call_count,1)
                self.assertEqual(request.call_count,1)

    def test_collection_cache_preserves_rejected_candidates(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch('flora.collector.ROOT',root), patch('flora.collector.time.sleep'), \
                 patch('flora.collector.json_call',side_effect=[{'queries':['장미']},{'page_ids':['a']}]), \
                 patch('flora.collector.requests.Session.get') as request:
                request.return_value.json.return_value = {'query':{'search':[
                    {'pageid':'a','title':'장미'}, {'pageid':'b','title':'무관한 후보'}]}}
                collect(self.plant('a','장미'),'장미의 특징',None)
                audit = json.loads(next((root/'data/search_cache').glob('*.json')).read_text(encoding='utf-8'))
                self.assertEqual(audit['selected_ids'],['a'])
                self.assertEqual(audit['rejected_ids'],['b'])
                self.assertTrue(audit['candidates'][0]['already_indexed_primary'])

if __name__=='__main__':
    unittest.main()
