import unittest
from flora.photos import is_photograph


class PhotographPolicyTests(unittest.TestCase):
    def test_botanical_art_is_excluded_even_as_jpeg(self):
        info = {'mime':'image/jpeg', 'metadata':[{'name':'Model','value':'Scanner'}],
                'extmetadata':{'ImageDescription':{'value':'Botanical illustration from Köhler'}}}
        self.assertFalse(is_photograph(info, 'File:Lily.jpg'))

    def test_camera_photo_is_accepted(self):
        info = {'mime':'image/jpeg', 'metadata':[{'name':'Model','value':'Canon EOS'}]}
        self.assertTrue(is_photograph(info, 'File:Dahlia flower.jpg'))

    def test_unknown_bitmap_and_seeds_are_not_flower_photos(self):
        self.assertFalse(is_photograph({'mime':'image/jpeg'}, 'File:Unknown.jpg'))
        info = {'mime':'image/jpeg', 'metadata':[{'name':'Model','value':'Canon EOS'}]}
        self.assertFalse(is_photograph(info, 'File:Canna seeds.JPG'))
