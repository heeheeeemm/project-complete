import os
import logging
import re
import streamlit as st
from flora.config import ROOT
from flora.data import load_data, load_meanings
from flora.pipeline import graph, explore, cited_sources
from flora.store import Store
from flora.photos import fetch_photo
from flora.ui import apply_styles, sidebar_brand, hero, section_intro, gift_note, footer
from flora.cards import build_card_notes, fallback_card

st.set_page_config(page_title='Flora AI · 꽃이 전하는 마음',page_icon='🌷',layout='wide')
apply_styles()

@st.cache_data
def dataset():
    """꽃말사전 전체를 포함한 추천 데이터."""
    return load_data()

@st.cache_resource
def store_resource():
    return Store()

@st.cache_data(ttl=3600, show_spinner=False)
def plant_photo(page_id, name=None):
    # 모든 꽃·식물에 촬영 사진 필터를 적용하고 실패도 캐시한다.
    try:
        return fetch_photo(page_id, name) if name else fetch_photo(page_id)
    except Exception:
        logging.warning('사진 조회 실패: %s', page_id)
        return None


def retry_photo():
    plant_photo.clear()

def show_plant_photo(plant, context='detail'):
    try:
        photo = plant_photo(plant['id'], plant['name'] if plant['id'].startswith('nihhs-') else None)
    except Exception:
        logging.exception('식물 사진 조회 실패: %s',plant['id'])
        photo = None
    if not photo:
        st.caption('실제 촬영 사진을 아직 불러오지 못했어요.')
        st.button('사진 다시 불러오기',key='retry_photo_'+context+'_'+str(plant['id']),on_click=retry_photo)
        return
    local = ROOT / photo['local_path'] if photo.get('local_path') else None
    st.image(str(local) if local and local.exists() else photo['url'],caption=plant['name']+' · 실제 촬영 사진',width='stretch')
    st.caption(f"사진: {photo['artist']} · {photo['license']}")
    links = f"[사진 원문·이용 조건]({photo['source_url']})"
    if photo.get('license_url'):
        links += f" · [라이선스]({photo['license_url']})"
    st.caption(links)

data = dataset()
plants = data['plants']
if not plants:
    st.title('🌷 Flora AI')
    st.warning('식물 데이터가 없습니다. prepare_flora.py를 먼저 실행해 주세요.')
    st.stop()
by_id = {p['id']:p for p in plants}
store = store_resource() if os.getenv('GMS_KEY') else None

def choose(pid):
    st.session_state.plant_id = pid
    st.session_state.active_tab = '🌿 식물 이야기'


def return_to_recommend():
    st.session_state.active_tab = '💐 마음을 전하는 꽃'


def select_flower():
    st.session_state.active_tab = '🌿 식물 이야기'


def restore_search(entry):
    key = entry['kind']
    if key == 'recommend':
        # 꽃 이름 검색 화면보다 복원한 추천 기록을 먼저 보여준다.
        st.session_state.direct_flower_search = ''
        st.session_state.last_flower_search = ''
    st.session_state.gift_context = entry.get('gift_context', {})
    st.session_state[key+'_results'] = entry['results']
    st.session_state[key+'_query'] = entry['query']
    st.session_state[key+'_input'] = entry['query']
    st.session_state.active_tab = '💐 마음을 전하는 꽃' if key == 'recommend' else '🔎 조건으로 찾기'

def sources_ui(answer, sources):
    used = cited_sources(answer,sources)
    if not used:
        st.caption('답변에 인용된 근거가 없습니다.')
        return
    with st.expander(f'답변에 사용한 근거 {len(used)}건'):
        for n,s in used:
            st.markdown(f"**[근거 {n}] {s['title']}** · {s['source_type']} · [원문 보기]({s['url']})")
            st.caption(s['text'][:450])
            if s['source_type']=='항목 메타데이터':
                for r in by_id.get(s.get('plant_id'),{}).get('meanings',[]):
                    st.markdown(f"꽃말 출처: [국립원예특작과학원 · {r['name']}]({r['url']})")

with st.sidebar:
    sidebar_brand()
    default = next((p['id'] for p in plants if p['name']=='장미'),plants[0]['id'])
    if 'plant_id' not in st.session_state:
        st.session_state.plant_id = default
    selected = st.selectbox('더 알아보고 싶은 꽃',list(by_id),key='plant_id',format_func=lambda pid:by_id[pid]['name'],on_change=select_flower)
    st.caption('이름을 입력하면 목록에서 바로 찾을 수 있어요.')
    if store:
        metadata_count, document_count = store.meta.count(), store.docs.count()
        st.caption(f'색인: 식물 {metadata_count}개 / 문서 {document_count}조각')
        if not metadata_count:
            st.warning('색인이 없습니다. index_flora.py를 먼저 실행해 주세요.')
    else:
        st.warning('GMS_KEY가 없습니다. .env에 설정해 주세요.')
    st.markdown('### 🕘 검색 기록')
    history_panel = st.container()
    st.divider()
    if not store:
        st.caption('마음 선택 추천은 바로 이용할 수 있어요. 추가 상황 상담은 AI 연결 후 이용할 수 있어요.')
    online = st.checkbox('질문에 맞는 외부 문서 추가 수집',value=True,help='이미 수집한 검색어의 문서는 재사용합니다.')
    if st.button('이 식물의 대화 지우기',width='stretch'):
        st.session_state.setdefault('chats',{}).pop(selected,None)
    with st.expander('출처와 서비스 안내'):
        st.markdown('[위키백과](https://ko.wikipedia.org/) · [국립원예특작과학원](https://www.nihhs.go.kr/usr/persnal/Flower_library.do?mc=MN0000000090)')
        st.caption('꽃말은 출처와 문화에 따라 다릅니다. 개화기는 지역과 재배 환경에 따라 달라질 수 있습니다.')
        st.caption('속·종·통칭을 포함한 식물 항목입니다. 꽃말이 확인된 항목만 마음별 추천에 사용합니다.')

hero()

recommend_tab,chat_tab,search_tab,dictionary_tab = st.tabs(
    ['💐 마음을 전하는 꽃','🌿 식물 이야기','🔎 조건으로 찾기','📖 모든 꽃말 찾기'],
    key='active_tab', on_change='rerun',
)
plant = by_id[selected]
if chat_tab.open:
    with chat_tab:
        st.button('← 다른 꽃 찾기', on_click=return_to_recommend, key='back_to_recommend')
        st.subheader(plant['name'])
        st.caption(' · '.join(x for x in [plant['scientific_name'],plant['family'],plant['rank']] if x))
        left,right = st.columns([2,1])
        with left:
            with st.container(key='plant_detail_photo'):
                show_plant_photo(plant)
            st.write(plant['text'][:500])
            st.markdown(f"[정보 원문 읽기]({plant['url']})")
        with right:
            with st.container(border=True):
                st.markdown('**이 꽃이 전하는 말**')
                if plant['meanings']:
                    for r in plant['meanings']:
                        st.write(r['meaning'])
                        st.markdown(f"[국립원예특작과학원 · {r['name']}]({r['url']})")
                else:
                    st.caption('연결된 공식 꽃말 자료가 없습니다. 확인된 식물 정보로 답해드릴게요.')
        st.divider()
        chats = st.session_state.setdefault('chats',{})
        messages = chats.setdefault(selected,[])
        for m in messages:
            with st.chat_message(m['role']):
                st.markdown(m['content'])
                if m['role']=='assistant':
                    sources_ui(m['content'],m.get('sources',[]))
        question = st.chat_input(f"{plant['name']}의 꽃말, 특징, 개화 시기를 물어보세요",disabled=not bool(store))
        if question:
            with st.chat_message('user'):
                st.write(question)
            with st.chat_message('assistant'):
                if not store.meta.count():
                    st.warning('색인이 없습니다. index_flora.py를 먼저 실행해 주세요.')
                else:
                    try:
                        with st.status('근거를 찾아보고 있습니다…',expanded=True) as status:
                            if online and not plant['id'].startswith('nihhs-'):
                                from flora.collector import collect
                                try:
                                    collect(plant,question,store,st.write)
                                except Exception:
                                    st.warning('추가 문서 수집에 실패해 저장된 자료로 답변합니다.')
                            st.write('식물 정보와 관련 문서에서 근거를 검색합니다.')
                            result = graph(store).invoke({'plant':plant,'question':question,'history':messages,
                                                          'sources':[],'answer':''})
                            status.update(label='근거 확인과 답변 생성 완료',state='complete',expanded=False)
                        st.markdown(result['answer'])
                        sources_ui(result['answer'],result['sources'])
                        messages.extend([{'role':'user','content':question},
                                         {'role':'assistant','content':result['answer'],'sources':result['sources']}])
                    except Exception:
                        st.error('답변을 만들지 못했습니다. GMS 연결과 색인 상태를 확인한 뒤 다시 시도해 주세요.')

def result_card(match, i, recommend, key):
    p = match['plant']
    with st.container(border=True, key=f'result_card_{key}_{i}_{p["id"]}'):
        st.markdown('### 🌼 '+p['name'])
        if recommend and match.get('match_type'):
            st.caption(match['match_type']+' · '+('선택한 마음이 꽃말에 담겨 있어요.' if match['match_type']=='직접 일치' else '함께 전하기 좋은 의미를 바탕으로 추천했어요.'))
        show_plant_photo(p, context=key+'_'+str(i))
        if recommend:
            st.markdown('**꽃말 · ' + ' / '.join(r['meaning'] for r in p['meanings']) + '**')
        # 열린 세션과 검색 기록에 저장된 이전 설명에도 문구 정리를 적용한다.
        reason = re.sub(r"\s*꽃말 자체가\s*[^\n]*?뜻은 아니에요[.!。]?", '', match['reason']).strip()
        st.write(reason)
        if recommend:
            context = st.session_state.get('gift_context', {})
            note = match.get('card_note') or fallback_card(p, context, i)
            gift_note(note)
            st.caption('받는 사람과 전하고 싶은 마음에 맞춰 쓴 창작 문구예요.')
            st.download_button('카드 문구 저장', note, file_name='flower-card.txt', mime='text/plain', key=f'note_{i}_{p["id"]}', width='stretch')
        with st.expander('꽃말과 추천 근거 살펴보기'):
            for evidence in match['evidence']:
                st.markdown(f"**{evidence['condition']}** · “{evidence['quote']}”")
            st.markdown(f"[식물 정보 출처]({p['url']})")
            for r in p['meanings']:
                st.markdown(f"꽃말: {r['meaning']} · [공식 출처]({r['url']})")
        st.button('이 꽃 더 알아보기',key=f'{key}_{i}_{p["id"]}',on_click=choose,args=(p['id'],),width='stretch')


def discovery(recommend):
    key = 'recommend' if recommend else 'explore'
    section_intro('01' if recommend else '03', 'FIND YOUR FEELING' if recommend else 'FIND YOUR FLOWER')
    st.subheader('어떤 마음을 전하고 싶나요?' if recommend else '어떤 꽃을 찾고 있나요?')
    st.caption('확인된 꽃말을 바탕으로 마음에 어울리는 꽃을 찾아요.' if recommend else '모든 조건의 근거를 확인할 수 있는 식물만 보여드립니다.')
    with st.form(key+'_form'):
        if recommend:
            left, right = st.columns(2)
            recipient = left.selectbox('누구에게 전하나요?', ['소중한 사람', '연인', '친구', '부모님', '선생님', '나 자신'])
            occasion = right.selectbox('어떤 순간인가요?', ['일상 속 작은 선물', '생일', '기념일', '졸업 / 새로운 시작'])
            feeling = st.radio('전하고 싶은 마음', ['감사', '사랑', '우정', '축복', '희망', '위로', '존경'], horizontal=True)
            st.caption('이야기를 입력하면 그 내용을 우선 반영해요. 비워두면 선택한 마음으로 추천해요.')
        query = st.text_input('더 들려주고 싶은 이야기 (선택)' if recommend else '원하는 조건', key=key+'_input', placeholder='예: 늘 곁에서 힘이 되어준 사람에게 선물하고 싶어요' if recommend else '봄에 피는 분홍색 꽃')
        submitted = st.form_submit_button('내 마음에 어울리는 꽃 찾기' if recommend else '조건에 맞는 식물 찾기',type='primary',disabled=not recommend and not bool(store),width='stretch')
    if submitted:
        if not recommend and not query.strip():
            st.warning('찾고 싶은 조건을 입력해 주세요.')
        else:
            try:
                search_query = query
                if recommend:
                    # 입력한 꽃 이름/마음을 기본값 '감사'로 덮어쓰지 않는다.
                    search_query = query.strip() or feeling + '의 마음'
                    card_feeling = feeling if not query.strip() else None
                    for meaning, words in {'감사':['감사','고마'], '사랑':['사랑','고백','연인'], '우정':['우정','친구'], '축복':['축복','축하'], '희망':['희망','응원'], '위로':['위로'], '존경':['존경']}.items():
                        if any(word in query for word in words):
                            card_feeling = meaning
                            break
                    st.session_state.gift_context = {'recipient':recipient, 'occasion':occasion, 'feeling':card_feeling, 'story':query.strip()}
                with st.spinner('당신의 마음과 닮은 꽃말을 찾고 있어요…'):
                    matches = explore(plants,search_query,recommend,related=recommend)
                if recommend and matches:
                    with st.spinner('전하고 싶은 마음을 카드에 정성껏 옮기고 있어요…'):
                        matches = build_card_notes(matches, st.session_state.gift_context)
                st.session_state[key+'_results'] = matches
                st.session_state[key+'_query'] = search_query
                st.session_state.setdefault('search_history',[]).insert(0,{
                    'kind':key, 'query':search_query, 'results':matches,
                    'gift_context':dict(st.session_state.get('gift_context',{})),
                })
            except Exception:
                logging.exception('꽃 추천/검색 실패: kind=%s', key)
                st.session_state.pop(key+'_results',None)
                st.error('추천을 완료하지 못했어요. 잠시 후 다시 시도해 주세요.')
    if key+'_results' in st.session_state:
        st.caption('검색 조건: '+st.session_state[key+'_query'])
        matches = st.session_state[key+'_results']
        st.markdown(f'**검색 결과 {len(matches)}개** · 최대 6개')
        if 0 < len(matches) < 6:
            st.caption('확인된 꽃말과 관련된 마음을 함께 살펴 추천해요.' if recommend else '입력한 조건을 모두 뒷받침하는 자료가 있는 식물만 표시합니다.')
        if not matches:
            st.info('모든 조건을 뒷받침하는 식물을 찾지 못했습니다. 조건을 줄이거나 다른 표현으로 검색해 주세요.')
        with st.container(key=key+'_results_grid'):
            for start in range(0,len(matches),2):
                columns = st.columns(2, gap='medium')
                for column,i in zip(columns, range(start,min(start+2,len(matches)))):
                    with column:
                        result_card(matches[i], i, recommend, key)
        if matches:
            st.caption('‘이 꽃 더 알아보기’를 누르면 해당 식물의 대화 화면으로 이동합니다.')

if recommend_tab.open:
    with recommend_tab:
        if 'direct_flower_search' not in st.session_state:
            st.session_state.direct_flower_search = st.session_state.get('last_flower_search', '')
        with st.container(key='quick_flower_search'):
            flower_name = st.text_input('찾고 싶은 꽃이 있나요?', placeholder='목화처럼 꽃 이름을 입력해 보세요', key='direct_flower_search')
        st.session_state.last_flower_search = flower_name
        if flower_name.strip():
            named = [p for p in plants if p['meanings'] and any(flower_name.strip() in name for name in [p['name']]+p['aliases'])]
            st.caption(f'이름 검색 결과 {len(named)}개')
            for item in named:
                with st.container(border=True):
                    st.subheader(item['name'])
                    show_plant_photo(item, context='direct')
                    for meaning in item['meanings']:
                        st.write('꽃말 · '+meaning['meaning'])
                        st.markdown(f"[국립원예특작과학원 출처]({meaning['url']})")
                    st.button('이 꽃 더 알아보기', key='direct_'+item['id'], on_click=choose, args=(item['id'],))
            if not named:
                st.info('이름이 일치하는 꽃이 없어요. ‘모든 꽃말 찾기’에서도 찾아보세요.')
            st.divider()
        else:
            discovery(True)
if search_tab.open:
    with search_tab:
        discovery(False)

if dictionary_tab.open:
    with dictionary_tab:
        collection = load_meanings()
        st.subheader('이름으로도, 마음으로도 찾아보세요')
        st.caption(f"출처별 꽃말 {len(collection['records']):,}개 · 색상·통칭·나무를 포함한 항목 수예요.")
        word = st.text_input('꽃 이름 또는 꽃말 검색', placeholder='목화, 사랑, 장미, Rose, Friendship…', key='dictionary_search')
        language = st.radio('자료 범위', ['전체', '국내 꽃말', '영문 역사 꽃말'], horizontal=True)
        st.caption('영문 자료는 역사적 꽃말 사전의 원문입니다. 국내 꽃말과 다를 수 있으며 자동 번역하거나 같은 꽃으로 합치지 않았어요.')
        records = [r for r in collection['records'] if (not word.strip() or word.strip().casefold() in (r['name']+' '+r['meaning']).casefold())
                   and (language == '전체' or r['language'] == ('ko' if language == '국내 꽃말' else 'en'))]
        st.write(f'검색 결과 {len(records):,}개')
        page_count = max(1, (len(records)+29)//30)
        page = st.selectbox('결과 페이지', range(1,page_count+1), key=f'dictionary_page_{word}_{language}')
        for row in records[(page-1)*30:page*30]:
            with st.container(border=True):
                st.markdown('**'+row['name']+'**')
                st.write(row['meaning'])
                st.markdown(f"[{row['source']}]({row['url']}) · {row['tradition']}")
        if not records:
            st.info('해당 이름이나 꽃말을 찾지 못했어요. 다른 이름이나 짧은 단어로 찾아보세요.')
        st.download_button('전체 꽃말 데이터 저장 (JSON)', __import__('json').dumps(collection, ensure_ascii=False, indent=2), file_name='flower_meanings.json', mime='application/json')

with history_panel:
    history = st.session_state.get('search_history',[])
    if not history:
        st.caption('꽃 추천이나 조건 검색을 하면 여기에 기록이 남아요.')
    else:
        st.caption('기록을 누르면 검색 결과를 다시 볼 수 있어요.')
        for i,entry in enumerate(history):
            icon = '💐' if entry['kind'] == 'recommend' else '🔎'
            st.button(f"{icon} {entry['query']}",key=f'search_history_{i}',
                      help=f"검색 결과 {len(entry['results'])}개",width='stretch',
                      on_click=restore_search,args=(entry,))
        st.button('검색 기록 지우기',width='stretch',
                  on_click=lambda: st.session_state.pop('search_history',None))

footer()
