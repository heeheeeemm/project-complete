from flora.data import load_data
from flora.store import Store

if __name__ == '__main__':
    plants = load_data()['plants']
    if not plants:
        raise SystemExit('먼저 python prepare_flora.py를 실행하세요.')
    store = Store()
    store.index(plants, lambda done,total: print(f'색인 {done}/{total}',flush=True))
    print(f'완료: 메타데이터 {store.meta.count()} · 문서 청크 {store.docs.count()}',flush=True)
