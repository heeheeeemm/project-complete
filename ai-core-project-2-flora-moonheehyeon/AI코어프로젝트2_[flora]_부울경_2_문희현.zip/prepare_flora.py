"""공식 꽃말 사전과 확보한 위키백과 원문으로 로컬 식물 데이터를 준비한다."""
import html
import json
import re
import os
import time
from datetime import datetime, timezone
from pathlib import Path
import requests
import mwparserfromhell
from flora.config import ROOT

LIBRARY = 'https://www.nihhs.go.kr/usr/persnal/Flower_library.do'

def plain(text):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', text))).strip()

def get_dictionary():
    cache = ROOT / 'data' / 'nihhs_dictionary.json'
    if cache.exists():
        return json.loads(cache.read_text(encoding='utf-8'))
    rows = []
    session = requests.Session()
    contact = os.getenv('WIKI_CONTACT','').strip()
    session.headers['User-Agent'] = f'FloraAI/0.1 ({contact}) python-requests' if contact else 'FloraAI/0.1 python-requests'
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    session.mount('https://', HTTPAdapter(max_retries=Retry(total=3, backoff_factor=2, status_forcelist=[429,500,502,503,504])))
    for page in range(1, 38):
        response = session.get(LIBRARY, params={'mc':'MN0000000090', 'pageIndex':page}, timeout=30)
        response.raise_for_status()
        for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>', response.text, re.S):
            cells = re.findall(r'<td\b[^>]*>(.*?)</td>', row, re.S)
            match = re.search(r"viewContent\('(\d+)'\)", row)
            if len(cells) == 3 and match:
                rows.append({'id':match[1], 'name':plain(cells[1]), 'meaning':plain(cells[2]),
                             'url':f'https://www.nihhs.go.kr/usr/persnal/Flower_today.do?mc=MN0000000089&dataNo={match[1]}'})
        print(f'꽃말사전 {page}/37 · {len(rows)}건', flush=True)
        time.sleep(0.7)
    rows = list({r['id']:r for r in rows}.values())
    cache.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    return rows

def clean_wiki(raw):
    code = mwparserfromhell.parse(raw)
    for tag in list(code.filter_tags()):
        if str(tag.tag).lower() in ('ref','gallery','math'):
            try: code.remove(tag)
            except ValueError: pass
    for link in list(code.filter_wikilinks()):
        if str(link.title).startswith(('파일:', 'File:', '분류:', 'Category:')):
            try: code.remove(link)
            except ValueError: pass
    text = code.strip_code(normalize=True, collapse=True)
    text = re.split(r'\n\s*(?:각주|외부 링크|참고 문헌|같이 보기)\s*\n',text)[0]
    return re.sub(r'\n{3,}', '\n\n', text).strip()

def main():
    (ROOT/'data').mkdir(exist_ok=True)
    dictionary = get_dictionary()
    source = json.loads((ROOT/'research/wikipedia_probe.json').read_text(encoding='utf-8'))
    plants = []
    for p in source['pages']:
        if not p.get('extract','').strip() or 'disambiguation' in p.get('pageprops',{}):
            continue
        raw = p['extract']
        code = mwparserfromhell.parse(raw)
        boxes = [t for t in code.filter_templates() if str(t.name).strip().replace('_',' ') in ('생물 분류','자동 생물 정보')]
        box = boxes[0] if boxes else None
        def field(name):
            return box.get(name).value.strip_code().strip().replace("'",'') if box and box.has(name) else ''
        text = clean_wiki(raw)
        if len(text) < 70:
            continue
        aliases = {p['title'], field('이름')}
        for t in code.filter_templates():
            if str(t.name).strip() == '다른 뜻 넘어옴' and t.params:
                aliases.add(str(t.params[0].value).strip())
        aliases.discard('')
        matches = [r for r in dictionary if r['name'] in aliases]
        # 동명이거나 속/종을 넘겨 추정해서 연결하지 않는다.
        sentences = re.split(r'(?<=[.!?。])\s+|\n+',text)
        flowering = [s for s in sentences if re.search(r'(꽃.{0,30}(?:핀다|피며|피고)|개화)',s)]
        colorwords = ['분홍색','붉은색','빨간색','노란색','흰색','백색','보라색','자주색','주황색','청색']
        colors = [c for c in colorwords if any(c in s and '꽃' in s for s in sentences)]
        plants.append({'id':str(p['pageid']), 'name':p['title'], 'aliases':sorted(aliases),
                       'scientific_name':field('학명'), 'family':field('과'),
                       'rank':'속' if field('속') and not field('종') else ('종/하위분류' if field('종') else '문서 항목'),
                       'text':text, 'url':p['fullurl'], 'revision':p.get('revisions',[{}])[0].get('revid',0),
                       'flowering_evidence':flowering[:6], 'colors':colors,
                       'meanings':matches, 'collected_at':source['checked_at']})
    out = {'updated_at':datetime.now(timezone.utc).isoformat(), 'plants':plants,
           'dictionary_count':len(dictionary), 'meaning_count':sum(bool(p['meanings']) for p in plants)}
    (ROOT/'data/plants.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"준비 완료: 식물 항목 {len(plants)}개, 공식 꽃말 연결 {out['meaning_count']}개",flush=True)

if __name__ == '__main__':
    main()
