# Flora AI — 꽃이 전하는 마음

부울경 · 2반 · 문희현

제출 파일: `AI코어프로젝트2_[flora]_부울경_2_문희현.zip`

한국어 위키백과와 공식 꽃말사전을 근거로 식물 정보를 설명하고 마음에 어울리는 꽃을 추천하는 Streamlit 앱입니다.

## 빠른 실행

Python 3.10 이상을 사용합니다. Windows PowerShell에서 ZIP 압축을 푼 폴더로 이동한 뒤 실행합니다.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# .env의 GMS_KEY와 영문 연락처 WIKI_CONTACT를 본인 정보로 수정
.\.venv\Scripts\python.exe -m streamlit run app.py
```

브라우저 주소는 http://localhost:8501 입니다. `.env`의 API 키는 제출 ZIP에 포함하지 않습니다. 제공된 data/chroma 색인은 433개 메타데이터/905개 문서 청크를 포함하므로 기본 실행에 재색인이 필요하지 않습니다. API 연결은 질문 답변·조건 탐색·맞춤 카드 작성에 사용합니다. 키가 없으면 경고를 표시하고 직접 마음 선택 추천과 준비된 카드 문구를 사용할 수 있습니다.

## 데이터 준비와 색인

```powershell
.\.venv\Scripts\python.exe prepare_flora.py
.\.venv\Scripts\python.exe collect_flower_meanings.py
.\.venv\Scripts\python.exe index_flora.py
```

기존 데이터를 그대로 사용할 때는 위 준비 절차를 다시 실행할 필요가 없습니다. prepare_flora.py는 제공된 research/wikipedia_probe.json과 공식 사전 캐시로 기본 자료를 만듭니다. collect_flower_meanings.py는 제공된 영문 원문 캐시를 사용하며 `--refresh` 시 원문을 다시 받습니다. index_flora.py는 GMS 임베딩 API를 사용합니다. 동일 ID·동일 내용은 다시 임베딩하지 않습니다. 청크 설정 변경 시 재색인이 필요합니다.

## 기능

필수 F2001~F2012: 항목 로드·색인, 질문별 검색어 추출과 외부 문서 선별·수집, 근거 검색·병합, LangGraph 답변, 실제 인용 근거/원문 표시, 식물별 채팅, 꽃 추천, 조건 탐색, 진행/오류 안내를 구현했습니다.

선택 심화 F2016: 위키백과 식물 설명과 국립원예특작과학원 꽃말 자료를 함께 색인하고 출처 유형을 구분합니다. 단일/여러 출처 답변 비교 증빙을 포함합니다. F2013~F2015는 미선택입니다. CSS 변경만으로 독립 프런트엔드 구현 완료를 주장하지 않습니다.

추가 기능: 실제 촬영 사진, 검색 기록 복원, 국내366개·영문 역사999개 꽃말 사전, 받는 사람·행사·마음·사연에 맞춘 카드 문구와 TXT 저장, 모바일 화면을 제공합니다. 추천 결과에서 ‘이 꽃 더 알아보기’를 누르면 해당 식물의 대화로 이동합니다. 대화·검색 기록은 현재 브라우저 세션 동안 유지됩니다.

## 구성과 설정

- flora/data.py: 데이터 로드·항목 텍스트
- flora/collector.py: 질문별 외부 검색·선별·수집·캐시
- flora/store.py: 청킹·임베딩·색인·검색
- flora/pipeline.py: LangGraph·조건 검증·꽃 추천
- flora/cards.py: 맞춤 창작 편지·실패 시 기본 편지
- flora/ui.py, assets/flora.css, .streamlit/config.toml, app.py: 화면
- flora_settings.json: 모델·임베딩·청크 크기1200·중복160·Top-k5

## 출처와 이용 조건

식물 설명은 위키백과, 공식 꽃말은 국립원예특작과학원, 영문 역사 사전은 Kate Greenaway의 Language of Flowers를 사용합니다. 사진은 파일마다 저작자·라이선스가 다릅니다. 원문 URL·개정 ID·변형 내역·정책은 [DATA_SOURCES.md](DATA_SOURCES.md)와 데이터 파일에 기록했습니다. 위키 텍스트의 원문별 조건, 사진별 이용조건, 기관 자료의 공공누리 표시를 확인해야 합니다. 모든 개별 자료의 재배포 허용 유형을 확정한 상태는 아닙니다.

꽃말은 출처·문화에 따른 상징입니다. 자료에 없는 꽃말·색상·개화기·효능은 추정하지 않습니다. 관련 마음 추천은 꽃말의 동일 의미를 단정하지 않으며 공식 표현과 추천 해석을 구분합니다. 창작 카드 문구는 식물 사실 근거가 아닙니다.

## 검증

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m pip check
```

현재18개 테스트와 고정 라이브러리 버전·pip check가 통과했습니다. 압축 해제본에서도 DB와 테스트를 확인합니다. 테스트는 위 명령으로 재실행할 수 있습니다. 개발 중 사용한 작업용 포장/브라우저 스크립트와 추가 도구 설치 목록은 제외하고 결과 JSON과 화면을 보존했습니다.

명세서4장별 결과·요구사항 대조표·테스트 표·제출 전 점검은 [docs/검증_결과.md](docs/검증_결과.md)에 있습니다. 원본 증빙은 docs/evidence/에 있습니다.

## 제출 구성

요구사항 정의서, RAG 설계문서, 프로젝트 결과, 검증 결과, 통합 Word 보고서, 구현 소스, 데이터·기존 색인, 실행 화면을 포함합니다. 현재 제출본 기준 셀프 체크리스트는 docs/2회차_셀프·상호_체크리스트.xlsx에 포함합니다. 실제 교육생의 상호 점검은 미수행이며 과거 PDF와 작성 도구는 제외합니다. `.env`, 가상환경, 로그, 검색/질문 캐시와 작업용 과거 문서는 제외합니다. 파일명과 문서 작성자에 부울경·2반·문희현을 반영했습니다. 산출물 위치는 [docs/제출_산출물_안내.md](docs/제출_산출물_안내.md)를 확인하세요.
